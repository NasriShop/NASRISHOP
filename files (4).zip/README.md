# نشر ZoubirNasriShop مجاناً — بدون دومين وبدون خادم

المجلد يحتوي على كل ما تحتاجه: `index.html` (المتجر كاملاً)، `firestore.rules`، `netlify.toml`.

---

## المرحلة 1 — انشر المتجر الآن (3 دقائق)

1. افتح <https://app.netlify.com/drop>
2. اسحب **مجلد** `zoubirnasrishop-site` كاملاً وأفلته في الصفحة.
3. خلال ثوانٍ تحصل على رابط مثل `https://fluffy-cat-12345.netlify.app`.
4. من `Site configuration → Change site name` غيّره إلى `zoubirnasrishop` ← يصبح الرابط:
   **`https://zoubirnasrishop.netlify.app`**

المتجر يعمل الآن مع HTTPS. في هذه المرحلة يعمل في **الوضع المحلي**: الطلبات تُحفظ في متصفح الزبون فقط
ولن تصلك. لذلك لا تطلق الإعلانات قبل المرحلة 2.

> بديل: `vercel.com` (نفس المبدأ) أو `pages.cloudflare.com` (الأسرع في الجزائر).

---

## المرحلة 2 — قاعدة البيانات Firebase (15 دقيقة) — إلزامية

1. <https://console.firebase.google.com> → **Add project** → اسم المشروع → عطّل Analytics → Create.
2. من القائمة اليسرى: **Build → Firestore Database → Create database** → اختر
   **Start in production mode** → المنطقة `eur3 (europe-west)` (الأقرب للجزائر).
3. **Project settings ⚙︎ → Your apps → `</>` (Web)** → سجّل التطبيق → انسخ كتلة `firebaseConfig`.
4. افتح `index.html` بمحرر نصوص، وابحث في الأعلى عن `window.FIREBASE_CONFIG` والصق القيم مكان
   `PASTE_...`. احفظ.
5. في Firestore → تبويب **Rules** → الصق محتوى `firestore.rules` → Publish.
6. أعد رفع المجلد إلى Netlify (اسحب وأفلت مرة أخرى في نفس الموقع).

### إدخال منتجاتك أول مرة
قواعد الأمان تمنع الكتابة من المتصفح. لإدخال منتجاتك:

1. في `firestore.rules` غيّر `allow write: if false;` إلى `if true;` في `products` و`shop`،
   و`allow read, update, delete: if false;` إلى `if true;` في `orders` → Publish.
2. افتح متجرك → لوحة التحكم (رمز المرور `zoubir2026`) → أضف منتجاتك واضبط أسعار التوصيل.
3. **مهم:** بعد الانتهاء، أعد `products` و`shop` إلى `false`. أبقِ `orders` على
   `allow read: if true` فقط إذا أردت رؤية الطلبات في اللوحة — واعلم أن هذا يجعل الطلبات
   قابلة للقراءة من أي شخص يعرف اسم مشروعك.

**الحل النظيف للطلبات:** فعّل `Authentication → Sign-in method → Email/Password`، أنشئ حساباً
لك، وغيّر قاعدة `orders` إلى `allow read, update, delete: if request.auth != null;`.
أخبرني إذا أردت أن أضيف شاشة تسجيل الدخول هذه إلى الملف.

---

## المرحلة 2.5 — تخزين الصور خارجياً (Cloudinary، 5 دقائق) — مهم قبل إضافة منتجاتك

بدون هذه الخطوة، كل صورة تُحوَّل إلى نص طويل ويُخزَّن **داخل** بيانات المنتج في Firestore — وهذا
يُثقل كل زيارة، لأن الزبون يُحمِّل تلك الصورة الكبيرة مع بيانات المنتج في كل مرة، ويُعرّضك لحد حجم
الوثيقة (1MB). Cloudinary يحل هذا: الصورة تُرفع مرة واحدة إلى خادم متخصص بالصور، ويُحفظ في
Firestore **رابط خفيف فقط** (بضع عشرات من الحروف)، والصورة تصل للزبون محسّنة ومضغوطة تلقائياً.

1. أنشئ حساباً مجانياً على <https://cloudinary.com> (25GB تخزين + نقل مجاناً شهرياً).
2. من **Dashboard** انسخ **Cloud name** (يظهر أعلى الصفحة مباشرة).
3. **Settings ⚙︎ → Upload → Add upload preset**:
   - Signing Mode: **Unsigned** (ضروري — لأن الرفع يحدث من متصفح لوحة التحكم مباشرة بدون خادم)
   - اختر اسماً للـ preset (مثلاً `zoubirnasrishop`)
   - Folder: `zoubirnasrishop` (اختياري)
   - Save
4. افتح `index.html`، ابحث عن `window.CLOUDINARY` في الأعلى، واملأ:
   ```js
   window.CLOUDINARY = {
     CLOUD_NAME: "اسم-حسابك",
     UPLOAD_PRESET: "zoubirnasrishop"
   };
   ```
5. احفظ وأعد رفع المجلد إلى Netlify.

بعدها، أي صورة تضيفها من لوحة التحكم تُرفع مباشرة إلى Cloudinary وتظهر فوراً بجودة محسّنة
(`f_auto,q_auto`) — لا شيء ثقيل يُخزَّن في قاعدة بياناتك.

> `UPLOAD_PRESET` غير السرّي بتصميمه (Unsigned) — لا مشكلة في وضعه داخل ملف الموقع العام؛
> فقط لا تفعّل خيار "Signed" لأنه يتطلب مفتاحاً سرياً لا يجب أن يظهر في متصفح الزبون.

---

## المرحلة 3 — أرشفة Google Sheets (اختيارية، 10 دقائق)

1. أنشئ جدول Google، سمِّ الورقة الأولى `Orders`.
2. `Extensions → Apps Script` → الصق ملف `google-apps-script.gs` (من حزمة الخادم السابقة).
3. غيّر `SECRET` إلى `ZN`.
4. `Deploy → New deployment → Web app` → Execute as: **Me** / Access: **Anyone** → انسخ رابط `/exec`.
5. ألصقه في لوحة التحكم → الإعدادات → «رابط Google Apps Script».

كل طلب جديد يُضاف تلقائياً إلى الجدول في نفس اللحظة.

---

## المرحلة 4 — الإعلانات

1. **Facebook**: `business.facebook.com` → Events Manager → Create Pixel → انسخ الـ ID،
   وضعه في `index.html` مكان `PIXEL_ID` ثم أزل علامات التعليق `<!-- -->` حول الكود.
2. **TikTok**: `ads.tiktok.com` → Assets → Events → Web Events → نفس الخطوات مع `TIKTOK_PIXEL_ID`.
3. صفحتا «سياسة الخصوصية» و«الاستبدال والإرجاع» جاهزتان في الفوتر — مراجعو فيسبوك يطلبونهما
   لمتاجر الدفع عند الاستلام.

---

## مولّد الإعلانات بالذكاء الاصطناعي

يحتاج مفتاح API من `console.anthropic.com`. أدخله من: لوحة التحكم → الإعدادات → `Anthropic API key`.
يُحفظ في **متصفحك أنت فقط** ولا يصل الزبائن. لا تكتبه داخل `index.html` أبداً.

---

## متى تشتري الدومين؟

بعد أول 10–20 طلبة. عندها: اشترِ الدومين (~12$/سنة)، وفي Netlify:
`Domain management → Add domain` واتبع التعليمات. لا يتغير أي شيء في المتجر، والرابط القديم
يبقى يعمل ويحوّل تلقائياً.
